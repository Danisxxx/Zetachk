'Coloque aqui cada formato solicitado, puedes sacar el apid y el apihasd en www.telegram.org.'
'Codigo creado por The Wordls Of Apis : Onwer -> Rex Await (max)'

apid = 27533879 #ipid
apihasd = '80029e88381fe5c63e364687906458a0'
token = '7874992604:AAHm2oybhI9T34nm00MyrHMxMTuYaWORUMc'