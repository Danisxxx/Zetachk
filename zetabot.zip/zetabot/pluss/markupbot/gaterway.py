from configs._def_main_ import *

@rexbt('gater')
async def exit(client, msg):
    await msg.edit_message_text(gatertt,reply_markup=atras)