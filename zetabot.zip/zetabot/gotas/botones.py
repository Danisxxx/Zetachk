from pyrogram.types import *

mainstart = InlineKeyboardMarkup([[InlineKeyboardButton("𝗚𝗮𝘁𝗲𝗿𝘄𝗮𝘆𝘀 「︎⚡️」︎",callback_data="gater"),InlineKeyboardButton("𝗧𝗼𝗼𝗹𝘀 「︎📍」︎",callback_data="tools"),],[InlineKeyboardButton("𝗣𝗲𝗿𝗳𝗶𝗹 ",callback_data="perfil"),InlineKeyboardButton("𝗕𝘂𝘆 ",callback_data="buy")],[InlineKeyboardButton("❗️𝗘𝘅𝗶𝘁❗️ ",callback_data="exit"),InlineKeyboardButton("information",callback_data="information")]])

atras = InlineKeyboardMarkup([[InlineKeyboardButton("𝗛𝗼𝗺𝗲 🌨",callback_data="home"),InlineKeyboardButton("❗️𝗘𝘅𝗶𝘁❗️",callback_data="exit")]])

dbre = InlineKeyboardMarkup([[InlineKeyboardButton("Español 🇪🇸",callback_data="es"),InlineKeyboardButton("❗️𝗘𝘅𝗶𝘁❗️",callback_data="exit")]])

homedb = InlineKeyboardMarkup([[InlineKeyboardButton("𝗛𝗼𝗺𝗲 🌨",callback_data="home")]])

regene = InlineKeyboardMarkup([[InlineKeyboardButton("Regenerar 🌨",callback_data="regene")]])

link = InlineKeyboardMarkup([[InlineKeyboardButton("BOT CHANNEL", url="t.me/Exzzex"), InlineKeyboardButton("BUY ZETA", url="t.me/Exzzex")]])
