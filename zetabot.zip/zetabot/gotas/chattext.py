startx = '''<b>
Zeta Home : >_$-Security System ⚠️
- - - - - - - - - - - - - - - - - - - - - - - - - -
[<a href="tg://user?id=">後</a>] Usuario: {name}|@{username}
[<a href="tg://user?id=">後</a>] Id: <code>{user_id}</code>
[<a href="tg://user?id=">後</a>] Plan: {rank}
- - - - - - - - - - - - - - - - - - - - - - - - - -
Puede usar /cmds para ver los comandos disponibles
</b>'''

cmds = '''<b>Welcome to Zeta chk Bot  | <code>{fecha_mx}, Monterrey, Mexico {hora_mx} 🌦</code>
                                                                             
[<a href="tg://user?id=">後</a>] Hello @{username} welcome to Zeta telegram bot, gateways, tools and functions are constantly being added, to know my different commands use the buttons shown here:
━━━━━━━━━━━━━
Api Bot Status is: Online ✅ | Zeta Api is Online!!
</b>'''

tools = '''<b>Zeta Tools / Page 1
━━━━━━━━━━━━
Bin Generator:
Format: <code>$gen 601120</code>
Condition: <code>Online! ✅</code>
━━━━━━━━━━━━
Sk Ckeck:
Format: <code>$sk sk_live </code>
Condition: <code>Online! ✅</code>
━━━━━━━━━━━━
BIN Lookup:
Format: <code>$bin 601120 </code>
Condition: <code>Online! ✅</code>
━━━━━━━━━━━━
Gen Address:
Format: <code>$dir Country_code </code>
Condition: <code>Online! ✅</code>
━━━━━━━━━━━━
IP Fraud Check:
Format: <code>$ip 1.1.1.1 </code>
Condition: <code>Online! ✅</code>
━━━━━━━━━━━━
</b>'''

next = '''<b>Zeta Tools / Page 2
━━━━━━━━━━━━
Bin Generator:
Format: <code>$gen 601120</code>
Condition: <code>Online! ✅</code>
━━━━━━━━━━━━
Sk Ckeck:
Format: <code>$sk sk_live </code>
Condition: <code>Online! ✅</code>
━━━━━━━━━━━━
BIN Lookup:
Format: <code>$bin 601120 </code>
Condition: <code>Online! ✅</code>
━━━━━━━━━━━━
Gen Address:
Format: <code>$dir Country_code </code>
Condition: <code>Online! ✅</code>
━━━━━━━━━━━━
IP Fraud Check:
Format: <code>$ip 1.1.1.1 </code>
Condition: <code>Online! ✅</code>
━━━━━━━━━━━━
</b>'''


comuni = """The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀\n[•] Username : @TheWorldsOfApis"""

controndb = """<b>[ϟ] Hello, how are you? Please, if you want to use the bot, register. Tap Spanish in the bot and you will be registered automatically. Good day.
</b>"""

buy = '''<b><code>([Lan - 🇪🇸 | Reg - LA])</code>

[<a href='tg://user?id='><b>ϟ</b></a>] 15 Dia Personal [ $ 3.00 ]
[<a href='tg://user?id='><b>ϟ</b></a>] 15 Dia  Grupo [ $ 3.00 ]
[<a href='tg://user?id='><b>ϟ</b></a>] 1 Mes Personal [ $ 7.00 ]
[<a href='tg://user?id='><b>ϟ</b></a>] 1 Mes Grupo [ $ 7.00 ]
[<a href='tg://user?id='><b>ϟ</b></a>] Codigo fuente [ $ 500 usd]
[<a href='tg://user?id='><b>ϟ</b></a>] Comprar : @Exzzex

[<a href='tg://user?id='><b>ϟ</b></a>] Estos serian los planes del bot si deceas adquirirlo privado.
</b>'''

buy_en = '''<b><code>([Lan - 🇺🇸 | Reg - US])</code>

[<a href='tg://user?id='><b>ϟ</b></a>] 15 Days Personal [ $ 3.00 ]
[<a href='tg://user?id='><b>ϟ</b></a>] 15 Days Group [ $ 3.00 ]
[<a href='tg://user?id='><b>ϟ</b></a>] 1 Month Personal [ $ 7.00 ]
[<a href='tg://user?id='><b>ϟ</b></a>] 1 Month Group [ $ 7.00 ]
[<a href='tg://user?id='><b>ϟ</b></a>] Source Code [ $ 500 USD ]
[<a href='tg://user?id='><b>ϟ</b></a>] Buy : @Exzzex

[<a href='tg://user?id='><b>ϟ</b></a>] These are the plans for the bot if you wish to acquire it privately.
</b>'''

perfil = '''
<b>Zeta bot / Get info. [☁️]</b>
━━━━━━━━━━━━━
• <b>User Info:</b>
• <b>Username:</b> @{username}
• <b>ID:</b> <code>{target_id}</code>
━━━━━━━━━━━━━
• <b>DB Info:</b>
• <b>Condition:</b> <code>[{rank}]</code> | • <b>Spam:</b> <code>{antispam}</code>
• <b>Bans:</b> <code>[{ban_text}]</code> | • <b>Credits:</b> <code>{credits}</code>
• <b>Expiration Plan:</b> <code>{expiration_text}</code>
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥
'''

gatertt = '''<b>[•]  <a href="tg://user?id=InefableRexBot">𝗚𝗮𝘁𝗲𝗿𝘄𝗮𝘆𝘀「︎⚡️」︎</a>

[•] AUth ⇾ <code>.ch </code>
[•] Charged [ 0 ]
[•] CCn [ 0 ]
[•] Mass [ 0 ]
                                                                                                                  
[•] Take : <code>0.5(sg)</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━</b>'''

bin = '''<b>Zeta bot / Info #Bin{binif} [☁️]

• Brand: <code>{brand}</code>
• Type: <code>{type}</code>
• Level: <code>{level}</code>
• Bank: <code>{bank}</code>
• Country: <code>{country_name} [{country_flag}]</code>
• Check by: @{name} [{rango}]
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>
'''

sk = '''<b>[•] <a href="tg://user?id=InefableRexBot">Sk Key 「︎📍」︎</a>

[•] Response  ⇾ <code>{res}</code>
[•] Message  ⇾ <code>{message}</code>
-
[•] chk ⇾ {name}
[•] Take ⇾ <code>0.2</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━</b>'''



nrd = '''<b>[•] <a href="tg://user?id=InefableRexBot">Generador Users 「︎📍」︎</a>

[•] genero ⇾ <code>{genero}</code>
[•] Name ⇾ <code>{mr} {first} {last}</code>      
[•] Correo ⇾ <code>{mail}</code>      
[•] Ciudad ⇾ <code>{ciudad}</code>      
[•] Estado ⇾ <code>{state}</code>       
[•] Pais ⇾ <code>{country}</code>      
[•] Codigo Postal⇾ <code>{zip}</code>
-
[•] chk ⇾ {name}
[•] Take ⇾ <code>0.2</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━</b>'''

ip = '''<b>[⛈] IP FOUND [✅] | <code>{ips}</code>
━━━━━━━━━━━━━
• RISK :   [ <u><i>Low Risk</i></u> ] 🌥

• Fraud Score : <code>{fraud_score}</code>
• IP : <code>{ips}</code>
• City : <code>{city}</code>
• Country : <code>{country}({country_code})</code>
• Region : <code>{region}</code>
• ZIP : <code>{zip_code}</code>
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

zip = '''<b>[•] <a href="tg://user?id=InefableRexBot">Codigo Postal 「︎📍」︎</a>

[•] Zip ⇾ <code>{cap}</code>
[•] Status ⇾ <code>True ✅</code>
[•] country  ⇾ <code>{pais}</code>          
[•] Ciudad ⇾ <code>{ciudad}</code>           
[•] Estado  ⇾ <code>{estado}</code>     
-
[•] chk ⇾ {name}
[•] Take ⇾ <code>0.2</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━</b>'''

gen = '''<b>[⌥] Onyx Generator | Luhn Algo:
━━━━━━━━━━━━━━
-60112088|05|25|xxx-
━━━━━━━━━━━━━━
<code>{cc1}</code>
<code>{cc2}</code>  
<code>{cc3}</code>
<code>{cc4}</code> 
<code>{cc5}</code>
<code>{cc6}</code>
<code>{cc7}</code>
<code>{cc8}</code>
<code>{cc9}</code>
<code>{cc10}</code>
━━━━━━━━━━━━━━
[ϟ] Bin : {bin} | [ϟ] Info:
{bank} | {vendor} | {type} | {level} | {country_name} ({flag})
━━━━━━━━━━━━━━
bot by : @mmenamore 🌤
</b>'''

chres = '''<b>[•]  <a href="tg://user?id=InefableRexBot">Stripe charged 「︎⚡️」︎</a>

[•] <code>{ccs}</code>
[•] Status ⇾ {stat}
[•] Response ⇾ {respo}
[•] Message ⇾ <code>{message}</code>
[•] Code ⇾ <code>{code}</code>
-
[•] take ⇾ 2.9 s
[•] Proxy ⇾ live ✅
[•] chk ⇾ {name}
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━</b>'''

key_template = '''<b>Admin Panel / Key Created. [☁️]

[<a href=t.me/Zetachkbot>後</a>] Key: <code>{key}</code>
[<a href=t.me/Zetachkbot>後</a>] Dias: <code>{dias}</code>
[<a href=t.me/Zetachkbot>後</a>] Admin: @{Username}
[<a href=t.me/Zetachkbot>後</a>] Condition: <code>{Condition}</code>
[<a href=t.me/Zetachkbot>後</a>] Expiration in: <code>{Valid}</code>
</b>'''

roles = '''<b>[<a href=t.me/Zetachkbot>後</a>] Sorry you do not have sufficient privileges to use this command</b>'''

nouser = '''<b>[User] No Existe El ID❗ => <code>{id}</code> En La DB</b>'''

info = '''
<b>Zeta bot / Get info. [☁️]</b>
- - - - - - - - - - - - - - - - - - - - - - - - - - 
• <b>User Info:</b>
• <b>Username:</b> @{username}
• <b>ID:</b> <code>{target_id}</code>
- - - - - - - - - - - - - - - - - - - - - - - - - - 
• <b>DB Info:</b>
• <b>Condition:</b> <code>[{rank}]</code> | • <b>AntiSpam:</b> <code>{antispam}</code>
• <b>Bans:</b> <code>[{ban_text}]</code> | • <b>Credits:</b> <code>{credits}</code>
• <b>Expiration Plan:</b> <code>{expiration_text}</code>
- - - - - - - - - - - - - - - - - - - - - - - - - - 
<code>Bot by:</code> <code>@Exzzex</code> 🌥
'''

regist = '''<b>[User] => You are not registered in the bot, please register with /register [🌦]</b>'''

banned = '''<b>[User] => You Are Banned From The Bot Sorry ⚠️</b>'''

textid = '''<b>Zeta bot / Get info. [☁️]
━━━━━━━━━━━━━
• Username: @{username} [<code>{user_id}</code>]
• First Name: {first_name}
• Chatid: <code>{chat_id}</code>
━━━━━━━━━━━━━
• Condition: <code>[{rango}]</code> | Rank: <code>[{role}]</code>
• Ban: <code>[{ban_status}]</code>
• Regist: <code>{fecha_registro}</code>
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

claim = '''<b>Zeta bot / System Key. [☁️]
━━━━━━━━━━
• Key: <code>{key}</code>
• id: <code>{msg.from_user.id}</code>
• Condition: <code>[Premium]</code>
• AntiSpam: <code>30</code>
• Expiration Key: <code>{expiration_date}</code>
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

groupinfo = '''<b>Zeta bot / Group Info. [☁️]
━━━━━━━━━━━━━
• Chat_id: <code>{group_id}</code>
• Name Group: <code>{group_name}</code>
• Type: Supergroup
• Condition: <code>[{plan}]</code>
• Expired in: <code>{expiration}</code>
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

textea = '''<b>[User] Ya te Encuentras registrado en el bot como @{user_username} ( {user_id} )</b>'''

texteb = '''<b>[User] Te Has Registrado En El Bot Como @{user_username}</b>'''

dolar = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Pesos Mexicanos es {pesos_mexicanos} MXN
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

arg = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Pesos Argentinos es {pesos_argentinos} ARS
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

bol = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Bolívares Venezolanos es {bolivares_venezolanos} VES
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

eur = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Euros es {euros} EUR
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

col = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Pesos Colombianos es {pesos_colombianos} COP
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

per = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Sol Peruano es {sol_peruano} PEN
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

bra = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Reales Brasileños es {reales_brasilenos} BRL
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

chi = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Pesos Chilenos es {pesos_chilenos} CLP
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

ecu = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Pesos Ecuatorianos es {pesos_ecuatorianos} USD
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

uru = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Pesos Uruguayos es {pesos_uruguayos} UYU
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

gtq = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Quetzales Guatemaltecos es {quetzales_guatemaltecos} GTQ
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

pyg = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Guaraníes Paraguayos es {guaranies_paraguayos} PYG
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

dom = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Pesos Dominicanos es {pesos_dominicanos} DOP
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

nio = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Córdobas Nicaragüenses es {cordobas_nicaraguenses} NIO
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

pab = '''<b>Zeta bot / Dolar Convertion. [☁️]

La cantidad de {dolar}$ en Balboas Panameñas es {balboas_panamenas} PAB
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>'''

ccn = 'Live CCN ✅'
livecc = 'Cc live'
fund = 'insufficient funds.'
aproved = 'Aproved ✅'
char = 'Cc live charge $3.99'
sst = 'success:True'
deadcc = 'Cc muerta ❌'
inco = 'Incorrecta respuesta'
cad = 'Cc Dead'
ereq = 'Error req'
