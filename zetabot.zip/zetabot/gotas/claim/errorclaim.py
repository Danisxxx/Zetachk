invalid = """<b>Zeta bot / System Key. [☁️]
━━━━━━━━━━━━
Status: Key invalid. ❌
Message: This key is invalid.
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>"""

provide_key = """<b>
Zeta bot / System Key. [☁️]
━━━━━━━━━━━━
Status: Key invalid. ❌
Message: This key is invalid.
━━━━━━━━━━━━━
<code>Bot by:</code> <code>@Exzzex</code> 🌥</b>"""