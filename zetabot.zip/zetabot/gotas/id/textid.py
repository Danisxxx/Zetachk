error_username = '''<b>[Error] => Could not find the user with that username. Please verify and try again.</b>'''
user_not_registered = '''<b>[User] => The specified user is not registered in the database.</b>'''
